import 'package:flutter/material.dart';
import 'app.dart';

//Hot Reload
void main() {
  //Run App
  runApp(const App());
}
